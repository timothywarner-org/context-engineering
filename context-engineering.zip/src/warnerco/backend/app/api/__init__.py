"""API routes for WARNERCO Robotics Schematica."""

from app.api.routes import router

__all__ = ["router"]
